import { EventEmitter, Injectable } from '@angular/core';


@Injectable()
export class postservice {
  
   postCard1:any[] = [
        {
          image: "/assets/img/boy.jpeg",
          name: "Praveen Kumar",
          id: "p1",
          time: "19 hours ago",
          content:
            "Wherever you go, no matter what the weather, always bring your own sunshine...",
          likeCount: 3,
          like: [
            {
              limage: "/assets/img/boy.jpeg",
              lname: "Sneka",
              id: "s2"
            },
            {
              limage: "/assets/img/girl.jpeg",
              name: "Sangavi",
              id: "s3"
            },
            {
              limage: "/assets/img/boy.jpeg",
              name: "Gayathri",
              id: "G4"
            }
          ],
          commentCount: 5,
          mainComment: [
            {
              image: "image",
              name: "Sneka",
              time: "19 hours ago",
              id: "s2",
              comment: "nice"
            },
            {
              image: "image",
              name: "Sangavi",
              time: "09 hours ago",
              id: "s3",
              comment: "good"
            }
          ],
          subComment: [
            {
              image: "image",
              name: "Sneka",
              time: "19 hours ago",
              id: "s2",
              comment: "thanks"
            },
            {
              image: "image",
              name: "Sangavi",
              time: "09 hours ago",
              id: "s3",
              comment: "nice"
            }
          ]
        },
        {
          image: "https://writestylesonline.com/wp-content/uploads/2018/11/MIchele-Circle-11.2018.png",
          name: "Sneka",
          id: "S1",
          time: "22 hours ago",
          content: "No matter what the weather, always bring your own sunshine...",
          likeCount: 30,
          like: [
            {
              limage: "/assets/img/girl.jpeg",
              name: "Praveen",
              id: "P2"
            },
            {
              limage: "/assets/img/boy.jpeg",
              name: "Sangavi",
              id: "s3"
            },
            {
              limage: "/assets/img/girl.jpeg",
              name: "Gayathri",
              id: "G4"
            }
          ],
          commentCount: 5,
          mainComment: [
            {
              image: "image",
              name: "Sneka",
              time: "19 hours ago",
              id: "s2",
              comment: "nice"
            },
            {
              image: "image",
              name: "Sangavi",
            }
          ],
          subComment: [
            {
              image: "image",
              name: "Sneka",
              time: "19 hours ago",
              id: "s2",
              comment: "thanks"
            },
            {
              image: "image",
              name: "Sangavi",
              time: "09 hours ago",
              id: "s3",
              comment: "nice"
            }
          ]
        }
      ];
      getPost(post){
        this.postCard1.push(post);
      }
    }    