import { Component, Input } from '@angular/core';
import { post } from 'selenium-webdriver/http';
import { postservice } from './postservice';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
 postCard1: {name: string}[] = [];
 message: {name: string}[] = [];


 constructor(private acc: postservice) {}

 ngOnInit() {
  console.log(this.message)

   this.postCard1 = this.acc.postCard1;
 }
}