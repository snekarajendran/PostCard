import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { postCard } from "./postCard/postCard";
import { postCardContent } from "./postCard/postCardContent/postCardContent";
import { postCardHeader } from "./postCard/postCardHeader/postCardHeader";
import { postCardFooter } from "./postCard/postCardFooter/postCardFooter";
import { postCardComment } from "./postCard/postCardComment/postCardComment";
import { FormControl, FormGroup, Validators} from '@angular/forms';
// import { postCommentContent } from "./postCard/postCardComment/postCommentContent/postCommentContent";
// import { postCommentHeader } from "./postCard/postCardComment/postCommentHeader/postCommentHeader";
// import { postCommentFooter } from "./postCard/postCardComment/postCommentFooter/postCommentFooter";
import { postservice } from './postservice';


//import { postCardLike } from "./postCard/postCardFooter/postCardLike/postCardLike";
//import { postCardSub } from "./postCard/postCardFooter/postCardComment/postCardSub/postCardSub";



@NgModule({
  declarations: [
    AppComponent,
    postCard,
    postCardHeader,
    postCardFooter,
    postCardContent,
    postCardComment,
  
    // postCommentContent,
    // postCommentFooter,
    // postCommentHeader
    // //postCardLike,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [postservice],
  bootstrap: [AppComponent]
})
export class AppModule { }
