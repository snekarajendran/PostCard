import { Component, OnInit, Input} from "@angular/core";

@Component({
  selector: "app-postCardContent",
  templateUrl: "./postCardContent.html"
})
export class postCardContent implements OnInit {
  constructor() {}

  ngOnInit() {}
  @Input() content;
}
