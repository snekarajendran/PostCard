import { Component, OnInit, Input} from "@angular/core";

@Component({
  selector: "app-messagePost",
  templateUrl: "./messagePost.html"
})
export class messagePost implements OnInit {
  constructor() {}

  ngOnInit() {}
  @Input() pos;

}
