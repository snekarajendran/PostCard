import { Component, OnInit, Input} from "@angular/core";

@Component({
  selector: "app-messagePostContent",
  templateUrl: "./messagePostContent.html"
})
export class messagePostContent implements OnInit {
  constructor() {}

  ngOnInit() {}
  @Input() cont;
}
