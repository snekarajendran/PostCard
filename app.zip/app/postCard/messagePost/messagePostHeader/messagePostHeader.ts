import { Component, OnInit, Input} from "@angular/core";

@Component({
  selector: "app-imagePostHeader",
  templateUrl: "./imagePostHeader.html"
})
export class imagePostHeader implements OnInit {
  constructor() {}

  ngOnInit() {}
@Input() name;
}
