import { Component, OnInit,Input } from "@angular/core";

@Component({
  selector: "app-postCardHeader",
  templateUrl: "./postCardHeader.html"
})
export class postCardHeader implements OnInit {
  @Input() names;
  constructor() {}

  ngOnInit() {
  } 
  

}

