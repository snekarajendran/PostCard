import { Component, OnInit,Input } from "@angular/core";
import { NgForOfContext } from '@angular/common';

@Component({
  selector: "app-postCardFooter",
  templateUrl: "./postCardFooter.html"
})
export class postCardFooter implements OnInit {
  constructor() {}

  ngOnInit() {}
  @Input() footer;
}
