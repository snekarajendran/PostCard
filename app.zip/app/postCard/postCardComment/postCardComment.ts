import { Component, OnInit,Input } from "@angular/core";
import { NgForOfContext } from '@angular/common';

@Component({
  selector: "app-postCardComment",
  templateUrl: "./postCardComment.html"
})
export class postCardComment implements OnInit {
  constructor() {}

  ngOnInit() {}
  @Input() comme;
}
