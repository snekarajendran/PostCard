import { Component, OnInit, Input } from "@angular/core";
import { post } from 'selenium-webdriver/http';

@Component({
  selector: "app-postCard",
  templateUrl: "./postCard.html"
})
export class postCard implements OnInit {
  public title = 'Angular App';
  public type = 0;
  private message:any= new Object();
  private image;
  private pos;
  constructor() {}

  ngOnInit() {
  }
  @Input() post;


createPost (type){
  
  let mes = {
    "id": "S1",
    "name": "Sneka",
    "time": "9 hrs ago",
    "type":1,
    "message": this.message
    
  };
  let image = {
    "id": "S1",
    "name": "Sneka",
    "time": "14 hrs ago",
    "type":2,
    "image": this.image,
  };
  if(type ==1){
    mes.type = type;
    this.passData(mes);
  }else if(type == 2){
    image.type=type;
    this.passData(image);
    console.log("");
  }
}
passData(data){
  this.post.getPost(data);
}

}

  
